//------------------------ commenter ou decommenter si utilisé ou pas --------
#define CutDDS    //coupure du DDS aprés mesure en mode standallone
#define languageEn    // english
//#define languageFr      // francais
#define Sdcard          // utilisation de la carte Sd
#define VNAJ            // fonctions VnaJ
//#define Debug           // mode debug
//#define SerialPrint     // envois de données sur port com
#define EventDuration 500   //rafraichissement mesure en standalone
//------------------------
#define MinFrq 23860900 // FTW  min freq = 1 Mhz
#define MaxFrq 1431655765 // FTW  max freq = 60 Mhz
#define freqMin  1000000
#define freqMax 60000000
#define MenuMax 4
#define BandeMax 12


#define PowerDown 0x04  //  Power down AD9851,50  
#define Normal 0x01     //  AD9851 RFCLK multiplier enable x 6 en mode normal

#define led  6        //Affectation des broches
#define Rele  5       //relais refexion, transmission 
#define ADC0  A0       //entrée mag
#define ADC1  A1      //entrée phs
#define SD_CS_PIN 9

#define  dpInEncoderA  2
#define  dpInEncoderB  3
#define  dpInEncoderPress 4


#define adc2Db 60/1024  // pente pleine echelle Db / resolution ADC = 0.0586
#define offsetDb -30  // décallage de -30db, pour ADC=512 -> 0db
#define Adc2Angle 180/1024  // pente pleine echelle Angle / resolution ADC = 0.175
#define D2R 3.14159/180    //degrés to radians



//#define calMag 0.703125      //before calibrate function
//#define calPhs 1.58203125



#ifdef languageEn
#define OpenDUT "Leave open DUT"
#define PressBtn "and press button"
#define Done "Done"
#define PressBtnTo "Press button to"
#define ReturnNormal "return normal mode"
#define MenuStandAlone "Standalone Reflect."
#define Fstart "Fstart:"
#define Fstep "Fstep:"
#define Samples "Samples:"
#endif

#ifdef languageFr
#define OpenDUT "Debrancher DUT et"
#define PressBtn "presser le bouton"
#define Done "Fin calibration"
#define PressBtnTo "presser le bouton"
#define ReturnNormal ""
#define MenuStandAlone "Mode autonome"
#define Fstart "Fdeb:"
#define Fstep "Fpas:"
#define Samples "Ech:"
#endif
