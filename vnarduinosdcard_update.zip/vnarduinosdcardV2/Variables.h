#ifdef Sdcard
SdFat SD;
File myFile;
#endif

unsigned char Mode;       //mode powerdown ou normal
unsigned long  StartF;    //DS_FTW fréquence de départ
unsigned int NumberF;     //nombre d'échantillons
unsigned long  StepF;     //Fréquence d'incrémentation en FTW (non en HZ)

//char Temp;
unsigned int intTemp;    //variable de boucle pour le balayage
unsigned int adcmag;     //variables des 2 ADC mesures
unsigned int adcphs;
boolean check = 0;

struct vector_reflection {
  double Freq;
  float RL;
  float Phi;
  float Rho;
  float Rs;
  float Xs;
  float Swr;
  float Z;
};
vector_reflection Point;

struct vector_transmission {
  double Freq;
  float TL;
  float TP;
};


float calMag;
float calPhs;

long Event;

volatile long freq = 5000000;
byte vnaMode = 0;
volatile byte menuSwapp = 0;
byte menuChoose = 0;
byte bandChoose;
byte MenuSelect; // 0 menu principal, 1 menu bande, 2 frequences
volatile byte bandSwapp = 0;
volatile byte bandSwappPrec = 11;
double dds_reg;
boolean CounterClockwise = false;
boolean ReverseCounterClockwise = false;


long freq_prec = 0;
long freqStep = 0;
LiquidCrystal_I2C lcd(0x27, 2, 1, 0, 4, 5, 6, 7, 3, POSITIVE);    //4 lines *20 columns lcd char
